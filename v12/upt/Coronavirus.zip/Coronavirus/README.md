# Coronavirus Data View
COVID-19 Novel Coronavirus Data View for quick analysis

Quick table view of nCoV Global Cases based on data from [Johns Hopkins CSSE](https://systems.jhu.edu/research/public-health/ncov/)

View at [https://www.instafluff.tv/Coronavirus/](https://www.instafluff.tv/Coronavirus/)
